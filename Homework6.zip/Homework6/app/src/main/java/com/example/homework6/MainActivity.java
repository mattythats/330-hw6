package com.example.homework6;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Radio station;
    RadioSubscriber person;
    TextView display;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        station = new Radio();
        person = new RadioSubscriber();
        display = findViewById(R.id.display_text);
        station.registerObserver(person);
    }

    public void update(View v){
        station.notifyObserver();
        display.setText(getString(R.string.display_placeholder, person.getSongs()));
    }
}
