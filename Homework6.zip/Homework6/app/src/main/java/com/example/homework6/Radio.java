package com.example.homework6;

import java.util.ArrayList;
import java.util.Random;

public class Radio implements Subject {

    private ArrayList<Observer> observers;
    private Random numSongs;

    public Radio(){
        observers = new ArrayList<>();
        numSongs = new Random();
    }

    public void registerObserver(Observer o) {
        observers.add(o);
    }

    public void removeObserver(Observer o) {
        int remove = observers.indexOf(o);
        if(remove > -1){
            observers.remove(remove);
        }
    }

    public void notifyObserver() {
        int n = numSongs.nextInt(30);
        for(int i = 0; i < observers.size(); i++) {
            Observer o = (Observer) observers.get(i);
            o.update(n);
        }
    }
}
