package com.example.homework6;

public class RadioSubscriber implements Observer{
    int songs;

    public RadioSubscriber(){
        songs = 0;
    }

    public void update(int numSongs) {
        songs = numSongs;
    }

    public int getSongs(){
        return songs;
    }
}
