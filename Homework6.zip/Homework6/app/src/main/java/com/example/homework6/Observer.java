package com.example.homework6;

public interface Observer {
    public void update(int numSongs);
}
